package basesdedatos.nose;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NoseApplicationTests {

	@Test
	void contextLoads() {
	}

}
